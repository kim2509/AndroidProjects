package com.common;

public class Constants {

	public final static String FAIL = "9999";
	public final static int RELOAD = 1000;
	
}
