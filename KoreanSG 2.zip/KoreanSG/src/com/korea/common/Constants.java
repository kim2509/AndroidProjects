package com.korea.common;

public class Constants {

	public final static String SUCCESS = "0000";
	public final static String FAIL = "9999";
	
	public final static int REQUEST_CODE_COMMON = 1000;
	public final static int REQUEST_CODE_COMMON2 = 1001;
	public final static int REQUEST_CODE_COMMON3 = 1003;
	public final static int REQUEST_CODE_COMMON4 = 1004;
	public final static int REQUEST_CODE_COMMON5 = 1005;
	public final static int REQUEST_CODE_COMMON6 = 1006;
}
